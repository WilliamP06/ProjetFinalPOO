from Mamifere import *
from Poisson import *
from Oiseau import *
from Enclos import *

mamifere1 = Mamifere(1.2, 32, 104, "s", "f", "sdfsd", 24)
print(mamifere1)

poisson1 = Poisson(1.2, 32, 104, "s", "f", "sdfsd", 24)
print(poisson1)

oiseau1 = Oiseau(1.2, 32, 104, "s", "f", "sdfsd", 24)
print(oiseau1)

enclos1 = Enclos("sfdsfse", "sfsfes", "sdfsfef")
print(enclos1)